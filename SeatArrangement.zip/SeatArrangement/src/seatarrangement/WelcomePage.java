package seatarrangement;

import java.awt.*;
import javax.swing.*;

public class WelcomePage {

    JFrame f;
    JPanel p1;
    JLabel lb1, lb2, lb3, lb4;
    Font font, font2;
    final JProgressBar pb;
    

    WelcomePage() {
        f = new JFrame("Welcome");
        f.setSize(716, 639);
        f.setDefaultCloseOperation(3);
        f.setLocationRelativeTo(null);
        f.setLayout(null);

        p1 = new JPanel();
        p1.setBounds(0,0,700, 600);
        p1.setBackground(new Color(20, 107, 121));
        p1.setLayout(null);
        f.add(p1);
        
        font = new Font("Merriweather", Font.PLAIN, 30);
        font2 = new Font("Merriweather", Font.PLAIN, 18);
        
        lb1 = new JLabel("Welcome");
        lb1.setBounds(280, 70, 600, 100);
        lb1.setForeground(new Color(10, 231, 255));
        lb1.setFont(font);
        p1.add(lb1);
        
        lb2 = new JLabel("To");
        lb2.setBounds(325, 115, 600, 100);
        lb2.setForeground(new Color(10, 231, 255));
        lb2.setFont(font);
        p1.add(lb2);
        
        lb3 = new JLabel("Seat Arrangement System");
        lb3.setForeground(new Color(10, 231, 255));
        lb3.setBounds(180, 160, 600, 100);
        lb3.setFont(font);
        p1.add(lb3);
        
        lb4 = new JLabel("Loading.....Please wait!!");
        lb4.setBounds(250, 430, 200, 50);
        lb4.setFont(font2);
        p1.add(lb4);
        
        pb = new JProgressBar(0, 100);
        pb.setBounds(100, 480, 500, 30);
        pb.setStringPainted(true);
        p1.add(pb);
        
        f.setVisible(true);
        
       for (int i = 0; i <= 100; i++) {
            final int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(100);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(f, e.getMessage());
            }
        }
        
        f.dispose();
        new Log_Sign();
    }
    
    public static void main(String[] args) {
        new WelcomePage();
    }
}
