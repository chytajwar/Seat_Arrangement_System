
package seatarrangement;
 
public class SeatArrangement {

    public static void main(String[] args) {
        
        new WelcomePage();
        
    }
    
}
