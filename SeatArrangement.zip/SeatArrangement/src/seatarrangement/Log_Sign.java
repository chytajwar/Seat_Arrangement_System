
package seatarrangement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Log_Sign implements ActionListener {
    
    JFrame f;
    JPanel p1;
    JLabel lb1, lb2;
    JButton btn1, btn2;
    
    Log_Sign(){
        
        f = new JFrame("Login & Sign-up");
        f.setSize(716, 639);
        f.setDefaultCloseOperation(3);
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        
        p1 = new JPanel();
        p1.setBounds(0, 0, 700, 600);
        p1.setBackground(new Color(255, 241, 182));
        p1.setLayout(null);
        f.add(p1);
        
        ImageIcon image = new ImageIcon("D:\\Versity\\CSE-3317_3318 (6th)\\Origin Coders\\image.png");
        Image imageIcon = image.getImage();
        Image newimg = imageIcon.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
        image = new ImageIcon(newimg);
        
        lb1 = new JLabel(image);
        lb1.setBounds(225, 50, 250, 230);
        lb1.setBackground(Color.yellow);
        p1.add(lb1);
        
        Font font = new Font("Arial", Font.BOLD, 15);
        
        lb2 = new JLabel("If you don't have an account please create a new one");
        lb2.setBounds(150, 450, 400, 60);
        lb2.setFont(font);
        p1.add(lb2);
        
        btn1 = new JButton("Login");
        btn1.setBounds(300, 280, 90, 40);
        btn1.setBackground(new Color(51, 255, 51));
        btn1.setFont(font);
        btn1.addActionListener(this);
        btn1.setFocusable(false);
        p1.add(btn1);
        
        btn2 = new JButton("Create New Account");
        btn2.setBounds(255, 340, 180, 40);
        btn2.setBackground(new Color(0, 255, 128));
        btn2.setFont(font);
        btn2.addActionListener(this);
        btn2.setFocusable(false);
        p1.add(btn2);
        
        f.setVisible(true);
        
    }
    
    public static void main(String[] args) {
        new Log_Sign();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        try{
            if (e.getSource()==btn1) {
                f.dispose();
                new LoginPage();
            }
            
            if (e.getSource()==btn2) {
                f.dispose();
                new RegistrationForm();
            }
        } catch(Exception ex){
            
        }
        
    }
}
