package seatarrangement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.regex.*;

public class RegistrationForm extends JFrame {

    JButton b1, b2;

    public RegistrationForm() {

        Font font1 = new Font("Agency FB", Font.BOLD, 36);
        Font font2 = new Font("Georgia", Font.PLAIN, 16);

        setTitle("Registration Form");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 684, 100);
        panel.setBackground(new Color(0, 0, 0));
        add(panel);
        panel.setLayout(null);

        JLabel label = new JLabel();
        label.setHorizontalAlignment(label.CENTER);
        label.setVerticalAlignment(label.CENTER);
        label.setBounds(0, 0, 700, 100);
        label.setText("Registration Form");
        label.setFont(font1);
        label.setForeground(new Color(150, 150, 150));
        panel.add(label);

        JPanel panel2 = new JPanel();
        panel2.setBounds(0, 100, 400, 361);
        panel2.setBackground(new Color(228, 228, 251));
        panel2.setLayout(null);
        add(panel2);

        JLabel label2 = new JLabel("User Name:");
        label2.setBounds(50, 50, 100, 30);
        label2.setFont(font2);
        label2.setForeground(Color.BLUE);

        JTextField field = new JTextField();
        field.setBounds(150, 50, 230, 30);
        field.setFont(font2);
        field.setEditable(true);
        panel2.add(label2);
        panel2.add(field);

        JLabel label3 = new JLabel("Email :");
        label3.setBounds(50, 100, 100, 30);
        label3.setFont(font2);
        label3.setForeground(Color.BLUE);

        JTextField field1 = new JTextField();
        field1.setBounds(150, 100, 230, 30);
        field1.setFont(font2);
        field1.setEditable(true);
        panel2.add(label3);
        panel2.add(field1);

        JLabel label4 = new JLabel("Password :");
        label4.setBounds(50, 150, 100, 30);
        label4.setFont(font2);
        label4.setForeground(Color.BLUE);

        JPasswordField pass = new JPasswordField();
        pass.setBounds(150, 150, 230, 30);
        pass.setEditable(true);
        panel2.add(label4);
        panel2.add(pass);

        JLabel label5 = new JLabel("C.Password :");
        label5.setBounds(50, 200, 100, 30);
        label5.setFont(font2);
        label5.setForeground(Color.BLUE);

        JPasswordField pass1 = new JPasswordField();
        pass1.setBounds(150, 200, 230, 30);
        pass1.setEditable(true);
        panel2.add(label5);
        panel2.add(pass1);

        b1 = new JButton("Submit");
        b1.setFont(font2);
        b1.setBounds(230, 270, 100, 60);
        b1.setFocusable(false);
        b1.setBackground(Color.GREEN);
        b1.setForeground(Color.white);
        panel2.add(b1);
        
        b2 = new JButton("Back");
        b2.setBounds(90, 270, 100, 60);
        b2.setFocusable(false);
        b2.setBackground(new Color(255, 51, 51));
        b2.setForeground(Color.white);
        panel2.add(b2);

        JPanel panel3 = new JPanel();
        panel3.setBounds(400, 100, 284, 361);
        //panel3.setBackground(Color.BLUE);
        panel3.setLayout(null);
        add(panel3);

        ImageIcon image = (new ImageIcon("D:\\Versity\\CSE-3317_3318 (6th)\\Origin Coders\\Registration.png"));
        Image imageIcon = image.getImage();
        Image newimg = imageIcon.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
        image = new ImageIcon(newimg);

        JLabel label6 = new JLabel(image);
        label6.setBounds(40, 70, 200, 200);
        label6.setBackground(Color.CYAN);

        panel3.add(label6);

        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                String user = field.getText();
                String password = pass.getText();
                String cpassword = pass1.getText();
                String mail = field1.getText();
                
                String userRegex = "[a-zA-Z]+";
                String mailRegex = "^[a-z0-9_]+@[a-z]+\\.[a-z]+[.]*[a-z]*";
                String passRegex = "(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{6,20}";
                

                if (!Pattern.matches(userRegex, user)) {
                    JOptionPane.showMessageDialog(null, "Only character is allowed in username");
                }
                else if(!Pattern.matches(mailRegex, mail)){
                    JOptionPane.showMessageDialog(null, "Give valid email");
                }
                else if(!Pattern.matches(passRegex, password)){
                    JOptionPane.showMessageDialog(null, "You must give 1 uppercase, 1 lowercase, 1 digit, 1 special character for password");
                }
                else if(!cpassword.equals(password)){
                    JOptionPane.showMessageDialog(null, "Must enter the same password");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Registration successfully completed");
                    String query = "Insert into admins values ('" + user + "','" + mail + "','" + password + "')";
                    Dbconnect db = new Dbconnect();
                    try {
                        db.insert(query);
                    } catch (Exception ex) {
                        
                    }
                    dispose();
                    new LoginPage();
                }
            }

        });
        
        b2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                dispose();
                new Log_Sign();
            }
            
        });

        setVisible(true);

    }

    public static void main(String[] args) throws Exception {

        new RegistrationForm();

    }

}

class Dbconnect {

    void insert(String query) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");

        String URL = "jdbc:mysql://localhost:3306/admintest";

        Connection con = DriverManager.getConnection(URL, "root", "");

        Statement st = con.createStatement();

        try {
            st.executeUpdate(query);
            st.close();
            con.close();
        } catch (Exception ax) {
            System.out.println("Error" + ax);
        }
        
    }
}
