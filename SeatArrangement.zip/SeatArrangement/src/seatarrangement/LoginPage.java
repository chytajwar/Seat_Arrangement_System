package seatarrangement;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class LoginPage {

    JFrame f;
    JPanel p1;
    JLabel lb1, lb2, lb3, imagelb1, imagelb2, imagelb3;
    JTextField tf1;
    JPasswordField tf2;
    JButton btn1, btn2;
    int flag = 0;

    LoginPage() {
        f = new JFrame("Login");
        f.setSize(716, 639);
        f.setDefaultCloseOperation(3);
        f.setLocationRelativeTo(null);
        f.setLayout(null);

        p1 = new JPanel();
        p1.setBounds(0, 0, 700, 600);
        p1.setBackground(new Color(135, 255, 255));
        p1.setLayout(null);
        f.add(p1);

        Font font = new Font("Arial", Font.BOLD, 30);
        Font font2 = new Font("Arial", Font.BOLD, 15);
        Font font3 = new Font("Times New Roman", Font.PLAIN, 18);

        lb1 = new JLabel("User Login");
        lb1.setBounds(270, 40, 200, 100);
        lb1.setForeground(new Color(255, 153, 52));
        lb1.setFont(font);
        p1.add(lb1);

        lb2 = new JLabel("Email:");
        lb2.setBounds(210, 130, 100, 30);
        lb2.setFont(font2);
        p1.add(lb2);

        tf1 = new JTextField();
        tf1.setBounds(210, 160, 280, 45);
        tf1.setFont(font3);
        p1.add(tf1);

        lb3 = new JLabel("Password:");
        lb3.setBounds(210, 220, 100, 30);
        lb3.setFont(font2);
        p1.add(lb3);

        tf2 = new JPasswordField();
        tf2.setBounds(210, 250, 280, 45);
        tf2.setFont(font3);
        p1.add(tf2);

        btn1 = new JButton("Login");
        btn1.setBounds(240, 320, 220, 45);
        btn1.setBackground(Color.GREEN);
        btn1.setFont(font2);
        btn1.setFocusable(false);
        p1.add(btn1);

        btn2 = new JButton("Back");
        btn2.setBounds(240, 380, 220, 45);
        btn2.setBackground(new Color(255, 51, 51));
        btn2.setFont(font2);
        btn2.setFocusable(false);
        p1.add(btn2);

        ImageIcon image1 = (new ImageIcon("D:\\Versity\\CSE-3317_3318 (6th)\\Origin Coders\\1st.png"));
        Image imageIcon = image1.getImage();
        Image newimg = imageIcon.getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        image1 = new ImageIcon(newimg);

        imagelb1 = new JLabel(image1);
        imagelb1.setBounds(100, 460, 80, 80);
        p1.add(imagelb1);

        ImageIcon image2 = (new ImageIcon("D:\\Versity\\CSE-3317_3318 (6th)\\Origin Coders\\2nd.png"));
        Image imageIcon2 = image2.getImage();
        Image newimg2 = imageIcon2.getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        image2 = new ImageIcon(newimg2);

        imagelb1 = new JLabel(image2);
        imagelb1.setBounds(320, 460, 80, 80);
        p1.add(imagelb1);

        ImageIcon image3 = (new ImageIcon("D:\\Versity\\CSE-3317_3318 (6th)\\Origin Coders\\3rd.png"));
        Image imageIcon3 = image3.getImage();
        Image newimg3 = imageIcon3.getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        image3 = new ImageIcon(newimg3);

        imagelb1 = new JLabel(image3);
        imagelb1.setBounds(500, 460, 80, 80);
        p1.add(imagelb1);

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tf1.getText();
                String password = tf2.getText();

                Dbconnect db = new Dbconnect();
                String query = "Select * FROM `admins`";
                try {
                    db.loginConnect(query, email, password);
                } catch (Exception ex) {
                    System.out.println("Error" + ex);
                }
            }
        });

        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                f.dispose();
                new Log_Sign();
            }

        });

        f.setVisible(true);
    }

    public static void main(String[] args) throws Exception {
        new LoginPage();
    }

    class Dbconnect {

        void loginConnect(String query, String email, String password) throws Exception {

            Class.forName("com.mysql.cj.jdbc.Driver");

            String URL = "jdbc:mysql://localhost:3306/admintest";

            Connection con = DriverManager.getConnection(URL, "root", "");

            Statement st = con.createStatement();

            try {
                ResultSet rs = st.executeQuery(query);
                while (rs.next()) {
                    String tableemail = rs.getString(2);

                    String tablepassword = rs.getString(3);

                    if (email.equals(tableemail) && password.equals(tablepassword)) {

                        flag = 1;

                    }
                }
            } catch (Exception ae) {
                System.out.println("Error" + ae);
            }

            if (flag == 1) {
                JOptionPane.showMessageDialog(null, "You are a valid user!!");
                flag = 0;
            } else {
                JOptionPane.showMessageDialog(null, "You are not a valid user!!");
            }
        }
    }
}
