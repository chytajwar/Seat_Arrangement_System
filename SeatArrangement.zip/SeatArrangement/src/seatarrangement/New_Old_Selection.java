
package seatarrangement;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class New_Old_Selection {
    
    Frame f;
    
    
}
